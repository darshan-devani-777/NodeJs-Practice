CREATE TABLE `migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `executed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `migrations` VALUES ('5', 'createUsersTable.ts', 'Fri Mar 13 2026 15:53:48 GMT+0530 (India Standard Time)');
INSERT INTO `migrations` VALUES ('6', 'createActivityLogsTable.ts', 'Fri Mar 13 2026 15:54:08 GMT+0530 (India Standard Time)');
INSERT INTO `migrations` VALUES ('7', 'createLoginHistoryTable.ts', 'Fri Mar 13 2026 15:54:08 GMT+0530 (India Standard Time)');
