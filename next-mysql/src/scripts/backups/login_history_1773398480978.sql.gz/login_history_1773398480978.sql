CREATE TABLE `login_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id_index` (`user_id`),
  CONSTRAINT `fk_login_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `login_history` VALUES ('1', NULL, '::1', 'PostmanRuntime/7.51.1', 'SUCCESS', 'Fri Mar 13 2026 16:08:57 GMT+0530 (India Standard Time)');
INSERT INTO `login_history` VALUES ('2', NULL, '::1', 'PostmanRuntime/7.51.1', 'SUCCESS', 'Fri Mar 13 2026 16:09:05 GMT+0530 (India Standard Time)');
INSERT INTO `login_history` VALUES ('3', '4', '::1', 'PostmanRuntime/7.51.1', 'SUCCESS', 'Fri Mar 13 2026 16:10:03 GMT+0530 (India Standard Time)');
