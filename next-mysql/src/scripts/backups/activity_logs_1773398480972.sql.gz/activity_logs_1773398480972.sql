CREATE TABLE `activity_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id_index` (`user_id`),
  CONSTRAINT `fk_activity_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `activity_logs` VALUES ('1', NULL, 'REGISTER', 'User registered: berlin@gmail.com', '::1', 'PostmanRuntime/7.51.1', 'SUCCESS', 'Fri Mar 13 2026 16:02:50 GMT+0530 (India Standard Time)');
INSERT INTO `activity_logs` VALUES ('2', NULL, 'REGISTER', 'User registered: admin@gmail.com', '::1', 'PostmanRuntime/7.51.1', 'SUCCESS', 'Fri Mar 13 2026 16:03:21 GMT+0530 (India Standard Time)');
INSERT INTO `activity_logs` VALUES ('3', NULL, 'REGISTER', 'User registered: denver@gmail.com', '::1', 'PostmanRuntime/7.51.1', 'SUCCESS', 'Fri Mar 13 2026 16:03:48 GMT+0530 (India Standard Time)');
INSERT INTO `activity_logs` VALUES ('4', NULL, 'REGISTER', 'User registered: peterapps70@gmail.com', '::1', 'PostmanRuntime/7.51.1', 'SUCCESS', 'Fri Mar 13 2026 16:04:16 GMT+0530 (India Standard Time)');
INSERT INTO `activity_logs` VALUES ('5', NULL, 'LOGIN', 'User logged in successfully', '::1', 'PostmanRuntime/7.51.1', 'SUCCESS', 'Fri Mar 13 2026 16:08:57 GMT+0530 (India Standard Time)');
INSERT INTO `activity_logs` VALUES ('6', NULL, 'LOGIN', 'User logged in successfully', '::1', 'PostmanRuntime/7.51.1', 'SUCCESS', 'Fri Mar 13 2026 16:09:05 GMT+0530 (India Standard Time)');
INSERT INTO `activity_logs` VALUES ('7', '4', 'EMAIL_VERIFY', 'Email verified successfully for peterapps70@gmail.com', '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', 'SUCCESS', 'Fri Mar 13 2026 16:09:51 GMT+0530 (India Standard Time)');
INSERT INTO `activity_logs` VALUES ('8', '4', 'LOGIN', 'User logged in successfully', '::1', 'PostmanRuntime/7.51.1', 'SUCCESS', 'Fri Mar 13 2026 16:10:03 GMT+0530 (India Standard Time)');
