CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `isActive` tinyint(1) DEFAULT 1,
  `isEmailVerified` tinyint(1) DEFAULT 0,
  `emailVerificationToken` varchar(255) DEFAULT NULL,
  `emailVerificationExpire` datetime DEFAULT NULL,
  `resetPasswordToken` varchar(255) DEFAULT NULL,
  `resetPasswordExpire` datetime DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatedAt` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `refreshToken` varchar(255) DEFAULT NULL,
  `refreshTokenExpire` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `email_index` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `users` VALUES ('1', 'Berlin', 'berlin@gmail.com', '$2b$10$H3q3Xq.9n7cerJH/kKHSyeEtFuAU48uJ.ePHOypQBx6vrTCY6mGKa', '1', '0', 'f13061adc137712f7267160660f40630f791e0911dae553b8ec211d4ec7d01fe', 'Sat Mar 14 2026 16:02:41 GMT+0530 (India Standard Time)', NULL, NULL, 'Fri Mar 13 2026 16:02:41 GMT+0530 (India Standard Time)', 'Fri Mar 13 2026 16:02:41 GMT+0530 (India Standard Time)', NULL, NULL);
INSERT INTO `users` VALUES ('2', 'Admin', 'admin@gmail.com', '$2b$10$MU93KGTb2e/Uqe7gqjPFnOZ9Gr796bq0rMYcMcNLewDsQ2GiHwpGS', '1', '1', '5a2f8653b63de36a004b43a4a1d4970fdac96fc2ca4599e46cd7c9bc1b31359e', 'Sat Mar 14 2026 16:03:18 GMT+0530 (India Standard Time)', NULL, NULL, 'Fri Mar 13 2026 16:03:18 GMT+0530 (India Standard Time)', 'Fri Mar 13 2026 16:04:30 GMT+0530 (India Standard Time)', NULL, NULL);
INSERT INTO `users` VALUES ('3', 'Denver', 'denver@gmail.com', '$2b$10$zi.edOWRQhQSjezWP9Auau5P6tlWkmUNye6HsvnIXVdZPsex35uKu', '1', '0', '9d7354a06391cac14c81926f938f5d3e15f0ddfb61bb120c5952f6c2a50ae8b4', 'Sat Mar 14 2026 16:03:45 GMT+0530 (India Standard Time)', NULL, NULL, 'Fri Mar 13 2026 16:03:45 GMT+0530 (India Standard Time)', 'Fri Mar 13 2026 16:03:45 GMT+0530 (India Standard Time)', NULL, NULL);
INSERT INTO `users` VALUES ('4', 'Peter Apps', 'peterapps70@gmail.com', '$2b$10$U16KcxwvM.di8K2U1wic3OpheEc/8i5DvyYOeAqQLbDeArpNIm/xS', '1', '1', NULL, NULL, NULL, NULL, 'Fri Mar 13 2026 16:04:13 GMT+0530 (India Standard Time)', 'Fri Mar 13 2026 16:59:42 GMT+0530 (India Standard Time)', '191b17402fbe3ecc36b352667cb0a23e9250f1f56017117b0012c79d6f2be07dacd54b8c9be8979e', 'Fri Mar 20 2026 16:59:42 GMT+0530 (India Standard Time)');
